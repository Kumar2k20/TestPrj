package contracts

import org.springframework.cloud.contract.spec.Contract

Contract.make {
    request {
        method 'GET'
        url '/coffee/2'
    }
    response {
        status OK()
        headers {
            contentType applicationJson()
        }
        body(
                id: 2,
                name: 'Cappuccino',
                quantity: 1,
                color: 'Black'
        )
    }
}