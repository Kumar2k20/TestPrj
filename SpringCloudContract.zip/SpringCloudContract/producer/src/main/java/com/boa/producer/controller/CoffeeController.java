package com.boa.producer.controller;

import com.boa.producer.model.Coffee;
import com.boa.producer.service.CoffeeMaker;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.server.ResponseStatusException;

@RestController
public class CoffeeController {

    private CoffeeMaker coffeeMaker;

    public CoffeeController(CoffeeMaker coffeeMaker) {
        this.coffeeMaker = coffeeMaker;
    }

    @GetMapping("coffee/{id}")
    public Coffee findCoffeeById(@PathVariable("id") Long id) {
        System.out.println("id: " + id);
        if (id == null) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Coffee id is null.");
        }
        Coffee coffee = coffeeMaker.findCoffee(id);
        if (coffee == null) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Coffee not found with id: " + id);
        }
        System.out.println(coffee);
        return coffee;
    }


}
