package com.boa.producer.model;

public class Coffee {
    private Long id;
    private String name;
    private Long quantity;
    private String color;

    public Coffee(Long id, String name, Long quantity, String color) {
        this.id = id;
        this.name = name;
        this.quantity = quantity;
        this.color = color;
    }

    @Override
    public String toString() {
        return "Coffee{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", quantity=" + quantity +
                ", color='" + color + '\'' +
                '}';

    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public Long getQuantity() {
        return quantity;
    }

    public String getColor() {
        return color;
    }


}
