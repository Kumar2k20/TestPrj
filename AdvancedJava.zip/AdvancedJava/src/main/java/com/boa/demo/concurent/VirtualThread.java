package com.boa.demo.concurent;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

public class VirtualThread {

    public static void main(String[] args) {
        ExecutorService executor = Executors.newVirtualThreadPerTaskExecutor();
        List<Future<Integer>> futures = new ArrayList<>();
        futures.add(executor.submit(() -> {
            waitForSometime();
            return 1;
        }));
        futures.add(executor.submit(() -> {
            waitForSometime();
            return 2;
        }));
        futures.add(executor.submit(() -> {
           waitForSometime();
            return 3;
        }));
        futures.add(executor.submit(() -> {
            waitForSometime();
            return 4;
        }));
        futures.add(executor.submit(() -> {
            waitForSometime();
            return 5;
        }));
        futures.add(executor.submit(() -> {
            waitForSometime();
            return 6;
        }));
        futures.add(executor.submit(() -> {
            waitForSometime();
            return 7;
        }));
        futures.add(executor.submit(() -> {
            waitForSometime();
            return 8;
        }));
        executor.shutdown();

        while(!executor.isTerminated()) {
            for(Future<Integer> future : futures) {
                try {
                    System.out.println(future.get() + " is completed");
                } catch (InterruptedException e) {
                    throw new RuntimeException(e);
                } catch (ExecutionException e) {
                    throw new RuntimeException(e);
                }
            }
        }

        System.out.println("Done");
        System.out.println("is Teminated :"+ executor.isTerminated());
        System.exit(0);

    }

    public static void waitForSometime() {
        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
    }
}
