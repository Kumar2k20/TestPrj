package com.boa.demo.reflection;


import java.lang.reflect.Field;

class PrivateFields {
    private String name;
    public String getName() {
        return name;
    }
}

public class AccessPrivate {
    public static void main(String[] args) throws NoSuchFieldException, IllegalAccessException {
        final PrivateFields instance = new PrivateFields();
        final Field field = PrivateFields.class.getDeclaredField( "name" );
        field.setAccessible( true );
        field.set( instance, "sample name" );
        System.out.println( instance.getName() );
    }
}
