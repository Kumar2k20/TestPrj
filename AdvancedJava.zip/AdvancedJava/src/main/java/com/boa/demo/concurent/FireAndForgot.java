package com.boa.demo.concurent;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class FireAndForgot {

    public static void main(String[] args) {
        ExecutorService executor = Executors.newFixedThreadPool(4);
        executor.execute(() -> {
            System.out.println("Hello World1");
            waitForSometime();
        });
        executor.execute(() -> {
            System.out.println("Hello World2");
            waitForSometime();
        });
        executor.execute(() -> {
            System.out.println("Hello World3");
            waitForSometime();
        });
        executor.execute(() -> {
            System.out.println("Hello World4");
            waitForSometime();
        });
        executor.execute(() -> {
            System.out.println("Hello World5");
            waitForSometime();
        });
        executor.execute(() -> {
            System.out.println("Hello World6");
            waitForSometime();
        });
        executor.execute(() -> {
            System.out.println("Hello World7");
            waitForSometime();
        });
        executor.execute(() -> {
            System.out.println("Hello World8");
            waitForSometime();
        });
        executor.shutdown();
        executor.execute(() -> {
            System.out.println("Hello World9");
            waitForSometime();
        });
    }

    public static void waitForSometime() {
        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
    }
}
