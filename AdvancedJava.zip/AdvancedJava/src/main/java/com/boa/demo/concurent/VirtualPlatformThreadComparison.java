package com.boa.demo.concurent;

import java.util.concurrent.ExecutionException;

public class VirtualPlatformThreadComparison {
    public static void main(String[] args) throws ExecutionException, InterruptedException {
        OSThreads osThreads = new OSThreads();
        VirtualThreads virtualThreads = new VirtualThreads();
        osThreads.run();
        virtualThreads.run();
       System.out.println("Logging the final result between OS threads and Virtual Threads");

    }
}
