package com.boa.demo.reflection;

import java.lang.reflect.Method;
import java.util.Arrays;
import java.util.stream.Collectors;

public class ExploreMethods {
    public static void main(String[] args) {
        final Method[] methods = String.class.getMethods();
        for( final Method method: methods ) {
            System.out.println(method.getReturnType().getName() + " " + method.getName() + " " + Arrays.stream(method.getParameterTypes()).collect(Collectors.toList()));
        }
    }
}
