package com.boa.demo.api;

import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;
import java.io.FileReader;

public class NashornExample {
    public static void main(String[] args) throws Exception{
        // Creating script engine
        ScriptEngine ee = new ScriptEngineManager().getEngineByName("nashorn");
        // Reading Nashorn file
        Object obj = ee.eval(new FileReader("hello.js"));
        System.out.println(obj);
    }
}
