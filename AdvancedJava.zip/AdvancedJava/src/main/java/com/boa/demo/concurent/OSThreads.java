package com.boa.demo.concurent;

import java.util.ArrayList;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;



public class OSThreads {

    private static long startTime;
    private final ExecutorService executorService;

    public OSThreads() {
        this.executorService = Executors.newFixedThreadPool(Runtime.getRuntime().availableProcessors() * 2);
    }

    public void run() throws ExecutionException, InterruptedException {
        System.out.println("Starting OS threads");
        startTime = System.currentTimeMillis();
        var futures = new ArrayList<Future<?>>();

        for (int i = 0; i < 200; i++) {
            var future = executorService.submit(() -> {
                try {
                    Thread.sleep(1000);
                    System.out.println("OS Thread completed :" + Thread.currentThread().getName());
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            });
            futures.add(future);
        }
        executorService.shutdown();
        for (var future : futures) {
            future.get();
        }
        System.out.println("OS threads completed in " + (System.currentTimeMillis() - startTime) + "ms");
        System.out.println("OS Threads completed");
    }
}
