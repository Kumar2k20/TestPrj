package com.boa.demo.concurent;

import java.util.ArrayList;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;


public class VirtualThreads {

    private static long startTime;
    private final ExecutorService executorService;

    public VirtualThreads() {
        this.executorService = Executors.newVirtualThreadPerTaskExecutor();
    }

    public void run() throws ExecutionException, InterruptedException {
        System.out.println("Starting Virtual threads");
        startTime = System.currentTimeMillis();
        var futures = new ArrayList<Future<?>>();

        for (int i = 0; i < 200; i++) {
            var future = executorService.submit(() -> {
                try {
                    Thread.sleep(1000);
                    System.out.println("Virtual Thread completed :" + Thread.currentThread().toString());
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            });
            futures.add(future);
        }
        executorService.shutdown();
        for (var future : futures) {
            future.get();
        }
        System.out.println("Virtual threads completed in " + (System.currentTimeMillis() - startTime) + "ms");
        System.out.println("Virtual Threads completed");
    }
}
