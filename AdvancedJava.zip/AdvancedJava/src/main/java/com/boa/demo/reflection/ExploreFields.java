package com.boa.demo.reflection;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Arrays;
import java.util.stream.Collectors;

class Car {
    public String color;
    public String name;
}

public class ExploreFields {
    public static void main(String[] args) {
        final Field[] fields = Car.class.getFields();
        for( final Field field: fields ) {
            System.out.println( field.getType().getName() + " " + field.getName() );
        }
    }
}
