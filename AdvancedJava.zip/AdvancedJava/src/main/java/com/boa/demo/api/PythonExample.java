package com.boa.demo.api;

import javax.script.Bindings;
import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;
import javax.script.ScriptException;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Reader;
import java.util.Arrays;
import java.util.Collection;


class Book {
    private final String author;
    private final String title;
    public Book(final String author, final String title) {
        this.author = author;
        this.title = title;
    }
    public String getAuthor() {
        return author;
    }
    public String getTitle() {
        return title;
    }
}

public class PythonExample {
    public static void main(String[] args) {
        System.setProperty("python.home", new File(
                System.getProperty("user.home"), "jython2.7.3").getPath()
        );

        final ScriptEngineManager factory = new ScriptEngineManager();
        final ScriptEngine engine = factory.getEngineByName( "jython" );

        final Collection< Book > books = Arrays.asList(
                new Book( "Mark Lutz", "Learning Python" ),
                new Book( "Jamie Chan", "Learn Python in One Day and Learn It Well" )
        );
        final Bindings bindings = engine.createBindings();
        bindings.put( "books", books );
        bindings.put( "engine", engine );
        try( final Reader reader = new InputStreamReader(
                Book.class.getResourceAsStream("/script.py" ) ) ) {
            engine.eval( reader, bindings );
        } catch (IOException | ScriptException e) {
            throw new RuntimeException(e);
        }
    }
}
