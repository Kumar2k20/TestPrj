var hello = function(){
    print("Hello Nashorn is started...");
    return "Hello Senthil";
};
hello();