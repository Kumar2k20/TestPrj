package com.example.resilience_demo.controller;

import com.example.resilience_demo.service.ResilienceService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class ResilienceController {

    @Autowired
    ResilienceService resilienceService;

    @GetMapping("/resilience-hello")
    public String getHello() {
        return resilienceService.getHello();
    }
}
