package com.example.demo.controller;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.example.demo.FirstspringbootApplication;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;


/**
 * @ExtendWith(SpringExtension.class) is an annotation used in JUnit 5 to integrate
 * the Spring TestContext Framework into JUnit 5's Jupiter programming model.
 * This allows you to use Spring's testing support in your JUnit 5 tests.
 * By using @ExtendWith(SpringExtension.class), you can leverage Spring's features in your tests, such as:
 * i.   Loading the Spring application context.
 * ii.  Injecting Spring-managed beans into your test classes.
 * iii. Managing transactions during tests.
 *
 *
 * @SpringBootTest is an annotation in Spring Boot that is used for integration testing.
 * It provides a way to create an application context for tests,
 * which allows you to test the full application context, including all the beans and configurations.
 * classes: This attribute can be used to specify the configuration classes to load for the test.
 *
 *
 * @WebAppConfiguration: Indicates that the ApplicationContext for the test should be a WebApplicationContext,
 * which is necessary for testing web-related components like controllers.
 *
 * In the provided test class, @WebAppConfiguration is used to ensure
 * that the WebApplicationContext is loaded,
 * allowing the MockMvc instance to be set up for testing the HelloController.
 */
@ExtendWith(SpringExtension.class)
@SpringBootTest(classes = FirstspringbootApplication.class)
@WebAppConfiguration
class HelloControllerTest {

    @Autowired
    private WebApplicationContext webApplicationContext;

    private MockMvc mockMvc;

    @BeforeEach
    public void setupMockMvc() {
        mockMvc = MockMvcBuilders.webAppContextSetup(webApplicationContext).build();
    }

    @Test
    void shouldReturnHelloWorld() throws Exception {
        mockMvc.perform(get("/hello"))
                .andExpect(status().isOk())
                .andExpect(content().string("Hello, World!"));

    }
}