package com.boa.producer.controller;

import com.boa.producer.model.Coffee;
import com.boa.producer.service.CoffeeMaker;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.server.ResponseStatusException;

@RestController
public class CoffeeController {

    private CoffeeMaker coffeeMaker;


    /**
     * The CoffeeController constructor will be invoked by the Spring Framework
     * when it creates an instance of the CoffeeController class.
     * This is done through dependency injection.
     * The CoffeeMaker service is automatically injected
     * into the CoffeeController by Spring
     * because it is annotated with @Service
     * and the CoffeeController is annotated with @RestController.
     * @param coffeeMaker
     *
     * 1) Spring Boot scans the application for classes annotated
     *      with @RestController and @Service.
     * 2) It finds the CoffeeController and CoffeeMaker classes.
     * 3) Spring Boot creates an instance of CoffeeMaker
     * and then uses it to create an instance of CoffeeController, injecting the CoffeeMaker instance into the CoffeeController constructor.
     */
    public CoffeeController(CoffeeMaker coffeeMaker) {
        this.coffeeMaker = coffeeMaker;
    }

    @GetMapping("coffee/{id}")
    public Coffee findCoffeeById(@PathVariable("id") Long id) {
        System.out.println("id: " + id);
        if (id == null) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Coffee id is null.");
        }
        Coffee coffee = coffeeMaker.findCoffee(id);
        if (coffee == null) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Coffee not found with id: " + id);
        }
        System.out.println(coffee);
        return coffee;
    }


}
