package com.boa.producer.service;

import com.boa.producer.model.Coffee;
import org.springframework.stereotype.Service;

import java.util.Map;

@Service
public class CoffeeMaker {
    private Map<Long, Coffee> coffeeMap = Map.of(
            1L, new Coffee(1L, "Latte", 1L, "Black"),
            2L, new Coffee(2L, "Cappuccino", 1L, "Black"),
            3L, new Coffee(3L, "Espresso", 1L, "Black"),
            4L, new Coffee(4L, "Turkish", 1L, "Black"),
            5L, new Coffee(5L, "Mocha", 1L, "Black")
    );

    public CoffeeMaker() {}


    public Coffee findCoffee(Long id) {
        return coffeeMap.get(id);
    }
}
