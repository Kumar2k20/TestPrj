package com.boa.producer;

import com.boa.producer.controller.CoffeeController;
import com.boa.producer.service.CoffeeMaker;
import io.restassured.module.mockmvc.RestAssuredMockMvc;
import org.junit.jupiter.api.BeforeEach;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.cloud.contract.verifier.messaging.boot.AutoConfigureMessageVerifier;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.test.web.servlet.setup.StandaloneMockMvcBuilder;

//@SpringBootTest(classes = ProducerApplication.class)
@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.MOCK)
@DirtiesContext
@AutoConfigureMessageVerifier
public class BaseClass {
    @Autowired
    CoffeeController coffeeController;

    @Autowired
    CoffeeMaker coffeeMaker;

    @BeforeEach
    public void setup() {
        StandaloneMockMvcBuilder standaloneMockMvcBuilder =
                MockMvcBuilders.standaloneSetup(coffeeController);
        RestAssuredMockMvc.standaloneSetup(standaloneMockMvcBuilder);

        /*Mockito.when(coffeeMaker.findCoffee(1L))
                .thenReturn(new Coffee(1L, "Cappuccino", 1L, "Black"));
        Mockito.when(coffeeMaker.findCoffee(2L))
                .thenReturn(new Coffee(2L, "Latte", 1L, "White"));*/


    }
}
