package com.boa.consumer;

import com.boa.consumer.model.Coffee;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.reactive.function.client.WebClient;

@RestController
public class ConsumerControlWebClient {

    @Autowired
    private WebClient webClient;

    @GetMapping("/orderCoffeeWC/{id}")
    public Coffee orderCoffee(@PathVariable("id") Long id) {
            return webClient.get()
                    .uri("/coffee/" + id) // Endpoint to fetch data
                    .retrieve() // Send the request and retrieve the response
                    .bodyToMono(Coffee.class)
                    .block(); // Convert the response body to a Mono<String>

    }


}
