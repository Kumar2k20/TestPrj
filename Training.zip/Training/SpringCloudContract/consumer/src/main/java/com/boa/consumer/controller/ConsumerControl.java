package com.boa.consumer.controller;

import com.boa.consumer.model.Coffee;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

@RestController
public class ConsumerControl    {

    //@Autowired
    //private RestTemplate restTemplate;

    private  RestTemplate restTemplate;


    private Integer pPort;
    public static Integer producerPort;

    @Autowired
    public ConsumerControl(RestTemplateBuilder builder) {
        this.restTemplate = builder.build();
    }

    @GetMapping("/orderCoffee/{id}")
    public Coffee orderCoffee(@PathVariable("id") Long id) {
        ResponseEntity<Coffee> responseEntity = restTemplate.getForEntity(
                "http://localhost:" + producerPort  + "/coffee/{id}", Coffee.class, id);

        return responseEntity.getBody();
    }

    @Value( "${producer.port}" )
    public void setPPort(Integer pPort) {
        producerPort = pPort;
        this.pPort = pPort;
    }

    public static void setProducerPort(Integer pPort) {
        producerPort = pPort;
    }
}
