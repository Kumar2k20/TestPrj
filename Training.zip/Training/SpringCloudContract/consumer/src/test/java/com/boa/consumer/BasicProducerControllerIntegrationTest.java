package com.boa.consumer;

import com.boa.consumer.controller.ConsumerControl;
import com.boa.consumer.model.Coffee;
import org.junit.jupiter.api.BeforeAll;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.json.AutoConfigureJsonTesters;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.cloud.contract.stubrunner.StubFinder;
import org.springframework.cloud.contract.stubrunner.spring.AutoConfigureStubRunner;
import org.springframework.cloud.contract.stubrunner.spring.StubRunnerProperties;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;


@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.MOCK)
@AutoConfigureMockMvc
@AutoConfigureJsonTesters
@AutoConfigureStubRunner(
        stubsMode = StubRunnerProperties.StubsMode.LOCAL,
        ids = "com.boa:producer:+:stubs")
public class BasicProducerControllerIntegrationTest {
    @Autowired
    private MockMvc mockMvc;

    @Autowired
    StubFinder stubFinder;

    @Test
    public void consumeCoffeeTest() throws Exception {
        RestTemplate restTemplate = new RestTemplate();
        int producerPort = stubFinder.findStubUrl("producer").getPort();
        ResponseEntity<Coffee> responseEntity = restTemplate.getForEntity(
                "http://localhost:" + producerPort + "/coffee/1", Coffee.class);
        assertThat(responseEntity.getStatusCodeValue()).isEqualTo(200);
        Coffee coffee = responseEntity.getBody();
        assertThat(coffee.getName()).isEqualTo("Latte");
    }

    @Test
    public void consumeCoffeeTest2() throws Exception {
        RestTemplate restTemplate = new RestTemplate();
        int producerPort = stubFinder.findStubUrl("producer").getPort();
        ResponseEntity<Coffee> responseEntity = restTemplate.getForEntity(
                "http://localhost:" + producerPort + "/coffee/2", Coffee.class);
        assertThat(responseEntity.getStatusCodeValue()).isEqualTo(200);
        Coffee coffee = responseEntity.getBody();
        assertThat(coffee.getName()).isEqualTo("Cappuccino");
    }


    @Test
    public void consumeCoffeeTest6() throws Exception {
        RestTemplate restTemplate = new RestTemplate();
        try {
            int producerPort = stubFinder.findStubUrl("producer").getPort();
            restTemplate.getForEntity(
                    "http://localhost:" + producerPort +"/coffee/6", Coffee.class);
        } catch (HttpClientErrorException e) {
            assertThat(e.getStatusCode()).isEqualTo(HttpStatus.NOT_FOUND);
        }
    }

    @Test
    public void orderCoffeeTest() throws Exception {
        int producerPort = stubFinder.findStubUrl("producer").getPort();
        ConsumerControl.setProducerPort(producerPort);
        this.mockMvc.perform(MockMvcRequestBuilders.get("/orderCoffee/1")
                        .contentType(MediaType.APPLICATION_JSON))
                .andDo(print())
                .andExpect(status().isOk())
                .andExpect(content().json("{\"id\":1,\"name\":\"Latte\",\"quantity\":1,\"color\":\"Black\"}"));
    }
}
