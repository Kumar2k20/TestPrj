package com.example.demo.controller;

import com.example.demo.service.HelloService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

//

//combines @Controller and @ResponseBody

/**
 * @Controller is used to define a Spring MVC controller that returns views (like JSP, Thymeleaf)
 *              and can use @ResponseBody to return data.
 * @RestController is a convenience annotation that combines @Controller and @ResponseBody,
 *              making every method return data directly (usually JSON or plain text) instead of a view.
 * Use @RestController for REST APIs, and @Controller for web pages.
 *
 */
@RestController
public class HelloController {
    @Autowired
    private HelloService helloService;

    @GetMapping("/hello")
    public String hello() {
        return "Hello, World!";
    }

    @GetMapping("/envName")
    public String helloAppName() {
        return "Hello, " + helloService.getEnvName() + " World!";
    }


}
