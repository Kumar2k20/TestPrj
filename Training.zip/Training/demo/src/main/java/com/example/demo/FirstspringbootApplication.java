package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * The @SpringBootApplication annotation is a convenience annotation that combines three other annotations:
 * @SpringBootConfiguration: Indicates that this is a Spring Boot configuration class.
 * @EnableAutoConfiguration: Enables Spring Boot's auto-configuration mechanism,
 * which automatically configures your Spring application based on the dependencies you have added.
 * @ComponentScan: Enables component scanning, so Spring can find and register beans within the package
 * (and sub-packages) where the application class is located.
 * Here is a breakdown of what each annotation does:
 *
 * @SpringBootConfiguration: This is a specialized form of @Configuration that is used to denote that
 * a class provides Spring Boot application configuration.
 * @EnableAutoConfiguration: This tells Spring Boot to start adding beans based on classpath settings,
 * other beans, and various property settings. For example, if spring-webmvc is on the classpath,
 * this annotation flags the application as a web application and activates key behaviors
 * such as setting up a DispatcherServlet.
 * @ComponentScan: This tells Spring to scan the current package and its sub-packages for components,
 * configurations, and services, allowing it to find and register beans.
 *
 */
@SpringBootApplication
public class FirstspringbootApplication {

	public static void main(String[] args) {
		/**
		 * SpringApplication.run(FirstspringbootApplication.class, args);
		 * method is used to launch a Spring Boot application.
		 *
		 * Bootstraps the application: It sets up the default configuration,
		 * starts the Spring application context, and performs a classpath scan.
		 * Starts the embedded server: If the application is a web application,
		 * it starts the embedded web server (e.g., Tomcat, Jetty).
		 * Initializes beans: It initializes all the Spring beans defined in the application context.
		 * Runs the application: It runs the application by calling
		 * the main method of the specified class (FirstspringbootApplication in this case).
		 */
		SpringApplication.run(FirstspringbootApplication.class, args);
	}

}
