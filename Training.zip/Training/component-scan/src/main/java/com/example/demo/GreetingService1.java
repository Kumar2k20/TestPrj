package com.example.demo;

import org.springframework.stereotype.Service;

@Service
public class GreetingService1 {
    public String greet() {
        return "Hello from GreetingService 1!";
    }
}
