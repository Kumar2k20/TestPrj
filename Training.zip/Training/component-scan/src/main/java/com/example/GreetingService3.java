package com.example;

import org.springframework.stereotype.Service;

@Service
public class GreetingService3 {
    public String greet() {
        return "Hello from GreetingService 3!";
    }
}
