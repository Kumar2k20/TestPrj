package com.example.demo;

import com.example.GreetingService3;
import com.example.demo.sub.GreetingService2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@SpringBootApplication
public class FirstspringbootApplication {

	public static void main(String[] args) {
		SpringApplication.run(FirstspringbootApplication.class, args);
	}

}


@RestController
class HelloController {

	@Autowired
	private GreetingService1 greetingService;  // ERROR: not found!

	@GetMapping("/")
	public String hello() {
		return greetingService.greet();
	}
}
