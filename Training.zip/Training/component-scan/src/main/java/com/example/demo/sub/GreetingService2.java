package com.example.demo.sub;

import org.springframework.stereotype.Service;

@Service
public class GreetingService2 {
    public String greet() {
        return "Hello from GreetingService 2!";
    }
}
