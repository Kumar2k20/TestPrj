package com.mt;

/*This is a simple example of a producer-consumer problem using synchronized block.
The producer and consumer threads are synchronized on the same object,
which is the instance of the Tree class. The producer thread adds leaves to the tree,
and the consumer thread removes leaves from the tree.
The producer thread waits if the tree is full, and the consumer thread waits if the tree is empty.*/

public class SampleThread5 {

    public static void main(String[] args) throws InterruptedException {
        Tree tree = new Tree();
        Thread producer = new Thread(() -> {
            try {
                tree.addLeaves();
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
        });

        Thread consumer = new Thread(() -> {
            try {
                tree.removeLeaves();
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
        });

        consumer.start();
        Thread.sleep(100);
        producer.start();
    }
}


class Tree {
    private int leafCount = 0;
private final int MAX_LEAF_COUNT = 5;
    private final int TIME_TO_SLEEP = 500;

    public synchronized void addLeaves() throws InterruptedException {
        while (true) {
            if(this.getLeafCount() == MAX_LEAF_COUNT) {
                System.out.println("Max leaf count reached, waiting for leaves to be removed...");
                this.notify();
                try {
                    this.wait();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
            leafCount++;
            Thread.sleep(TIME_TO_SLEEP);
            System.out.println("Leaf produced: " + this.getLeafCount());
        }
    }

    public  synchronized void removeLeaves() throws InterruptedException {
        while (true) {
            if(this.getLeafCount() == 0) {
                System.out.println("No leaves to remove, waiting for leaves to be added...");
                this.notify();
                try {
                    this.wait();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
            System.out.println("Leaf dropped: " + this.getLeafCount());
            leafCount--;
            Thread.sleep(TIME_TO_SLEEP);
        }
    }

    public int getLeafCount() {
        return leafCount;
    }
}


