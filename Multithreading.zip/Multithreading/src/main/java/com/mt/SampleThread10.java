package com.mt;

import java.util.concurrent.*;

/*  The Callable interface is similar to Runnable, in that both are designed for classes whose instances are potentially
    executed by another thread. A Runnable, however, does not return a result and cannot throw a checked exception.
    The Callable interface, on the other hand, returns a result and throws a checked exception.
    The Callable interface uses the call() method to perform the task and return the result.
    The ExecutorService interface provides the submit() method, which accepts a Callable object and returns a Future object.
    The Future object is used to retrieve the result of the Callable object.
    The Future object's get() method is used to retrieve the result of the Callable object.
    The get() method blocks until the result is available.
    The get() method throws an InterruptedException if the thread is interrupted while waiting for the result.
    The get() method throws an ExecutionException if the Callable object throws an exception.
    The get() method throws a TimeoutException if the result is not available within the specified timeout.
    The ExecutorService interface provides the shutdown() method to shut down the executor service.
    The shutdown() method allows previously submitted tasks to execute before terminating the executor service.
    The shutdownNow() method is used to shut down the executor service immediately.
    The shutdownNow() method attempts to stop all actively executing tasks, halts the processing of waiting tasks, and returns a list of the tasks that were waiting to be executed.

 */
public class SampleThread10 {

    public static void main(String[] args) {
        ExecutorService executorService = Executors.newFixedThreadPool(2);

        Callable<Integer> task = () -> {
            System.out.println("Task is running...");
            Thread.sleep(5000);
            return 100;
        };

        //Callable<Integer> task2 = new Task();
        Future<Integer> future = executorService.submit(task);

        try {
            Integer result = future.get();
            //Integer result = future.get(2, TimeUnit.SECONDS);
            System.out.println("Result from task: " + result);
        } catch (InterruptedException | ExecutionException e) {
            e.printStackTrace();
        }  finally {
            executorService.shutdown();
        }
    }
}

class Task implements Callable<Integer> {
    @Override
    public Integer call() throws Exception {
        System.out.println("Task is running...");
        Thread.sleep(5000);
        return 100;
    }
}