package com.mt;

import java.util.List;
import java.util.Random;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

/* this Example demonstrates how to use the ExecutorService to create a thread pool.
The ExecutorService is a higher-level replacement for the Executor interface.
It is a thread pool that creates and manages threads for you.
It is a good practice to use the ExecutorService to manage threads in a multithreaded application.
The ExecutorService provides a simple way to create a thread pool and run tasks in parallel.
The ExecutorService interface provides a simple way to create a thread pool and run tasks in parallel.
 */
public class SampleThread6 {

    public static void main(String[] args) throws InterruptedException {
        ExecutorService executor = Executors.newFixedThreadPool(5);
        Random r = new Random();
        for (int i = 0; i < 100; i++) {
            int finalI = i;
            executor.execute(() -> {

                System.out.println(Thread.currentThread().getName() + " Task " + finalI);
                try {
                    Thread.sleep( r.nextInt(1000) + 1000);
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                }
            });
        }

        System.out.println("Submitted all threads");

        executor.shutdown();
        /*List<Runnable> list = executor.shutdownNow();
        System.out.println("List size: " + list.size());*/
    }

}
