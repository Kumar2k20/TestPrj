package com.mt;

import java.util.concurrent.ThreadFactory;

/* SampleThread2.java
    *  This class demonstrates the use of Runnable interface to create a thread.
 */
public class SampleThread2 {
    public static void main(String[] args)  {
        System.out.println(Thread.currentThread().getName() + " Main Thread");
        Thread myThread1 = new Thread(new MyRunnableThread("Thread1"));
        Thread myThread2 = new Thread(new MyRunnableThread("Thread2"));
        myThread1.start();
        try {
            myThread1.join();
        } catch (InterruptedException e) {
           Thread.currentThread().interrupt();
        }
        myThread2.start();

        if (myThread1.isInterrupted()) {
            System.out.println("Thread1 was interrupted, exiting gracefully..."+Thread.currentThread().isInterrupted());
        } else {
            System.out.println("Thread1 was not interrupted, continuing..."+Thread.currentThread().isInterrupted());
        }

    /*Runnable runnable = new MyRunnableThread("MyRunnableThread");

    Runnable runnable1 =
        () -> { System.out.println("Lambda Runnable running"); };

    Thread thread1 = Thread.ofPlatform().daemon().start(runnable);
    Thread thread2 = Thread.ofPlatform().name("MyThread1").unstarted(runnable);
    Thread thread3 = Thread.ofVirtual().start(runnable);

    ThreadFactory factory1 = Thread.ofPlatform().daemon().name("worker-", 0).factory();
    ThreadFactory factory2 = Thread.ofVirtual().factory();

    Thread thread4 = factory1.newThread(runnable);
    Thread thread5 = factory2.newThread(runnable);*/

    }

}

class MyRunnableThread implements Runnable{

    String name;

    public MyRunnableThread(String name) {
        this.name = name;
    }

    @Override
    public void run() {
        for(int i = 0; i < 100; i++) {
            System.out.println(name + " Value " + i);
        }
    }
}
