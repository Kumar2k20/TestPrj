package com.mt;

/* SampleThread3.java
 *  This class demonstrates the use of interrupt method to stop a thread.
 */
public class SampleThread3  {
    public static void main(String[] args) {
        Thread thread = new Thread(() -> {

            try {
                while (!Thread.currentThread().isInterrupted()) {
                    // Simulate blocking operation (e.g., sleep or I/O)
                    System.out.println("Thread is running..." + Thread.currentThread().isInterrupted());
                    Thread.sleep(1000);
                }
            } catch (InterruptedException e) {
                // InterruptedException clears the interrupt status
                System.out.println("Caught InterruptedException!"+ Thread.currentThread().isInterrupted());
                // Re-establish the interrupt status
                Thread.currentThread().interrupt();
            }

            // Check for interrupted status later
            if (Thread.currentThread().isInterrupted()) {
                System.out.println("Thread was interrupted, exiting gracefully..."+Thread.currentThread().isInterrupted());
            } else {
                System.out.println("Thread was not interrupted, continuing..."+Thread.currentThread().isInterrupted());
            }
        });

        thread.start();

        try {
            Thread.sleep(5000);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }

        // Interrupt the thread during its sleep
        thread.interrupt();
    }
}