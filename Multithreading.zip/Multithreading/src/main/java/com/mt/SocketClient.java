package com.mt;

import java.io.*;
import java.net.Socket;
import java.util.Scanner;

public class SocketClient {
    public static void main(String[] args) {
        String hostname = "localhost"; // Server address
        int port = 8080; // Server port

        try (Socket socket = new Socket(hostname, port);
             OutputStream output = socket.getOutputStream();
             PrintWriter writer = new PrintWriter(output, true);
        ) {
            System.out.println("Connected to server");
            long count = 0;
            while (true) {
                String message = String.valueOf(++count);
                writer.println(message);
                System.out.println("Sent to server: " + message);
                //Thread.sleep(10);
                if(count >= 100) {
                    break;
                }
            }
        } catch (IOException ex) {
            ex.printStackTrace();
        }

    }
}
