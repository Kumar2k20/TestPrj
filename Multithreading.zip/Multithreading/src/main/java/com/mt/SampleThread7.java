package com.mt;

import java.util.concurrent.Executors;


/**
 * This class demonstrates how to create a virtual thread using Thread.startVirtualThread() method.
 * It also demonstrates how to create a virtual thread using Executors.newVirtualThreadPerTaskExecutor() method.
 */
public class SampleThread7 {
    public static void main(String []args) {
        Thread.startVirtualThread(() -> {
            System.out.println("Running in a virtual thread!");
        });

            // Using Executors.newVirtualThreadPerTaskExecutor()
        try (var executor = Executors.newVirtualThreadPerTaskExecutor()) {
            executor.submit(() -> {
                System.out.println("Task running in a virtual thread!");
            });
        }
    }
}
