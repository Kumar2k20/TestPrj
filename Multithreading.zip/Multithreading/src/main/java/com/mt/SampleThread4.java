package com.mt;

import java.util.concurrent.atomic.AtomicBoolean;

/* SampleThread4.java
 *  This class demonstrates the use of AtomicBoolean to check if threads are done.
 *  It uses two threads to increment a counter and checks if both threads are done before printing the final count.
 *  synchronized block
 *
 * A race condition is a concurrency problem that may occur inside a critical section.
 * A critical section is a section of code that is executed by multiple threads and where the sequence of execution
 * for the threads makes a difference in the result of the concurrent execution of the critical section.
 */
public class SampleThread4 {
    public static void main(String[] args) throws InterruptedException {
        Counter counter = new Counter();
        AtomicBoolean t1IsAlive = new AtomicBoolean(true);
        AtomicBoolean t2IsAlive = new AtomicBoolean(true);

        Thread t1 = new Thread(() -> {
            for (int i = 0; i < 100000; i++) {
                counter.increment();
            }
            t1IsAlive.set(false);
        });

        Thread t2 = new Thread(() -> {
            for (int i = 0; i < 100000; i++) {
                counter.increment();
            }
            t2IsAlive.set(false);
        });

        t1.start();
        t2.start();

        while (t1IsAlive.get() || t2IsAlive.get()) {
            System.out.println("Both threads are not done");
            Thread.sleep(1);
        }

        int finalCount = counter.getCount();
        System.out.println("Final count: " + finalCount);
    }
}


class Counter {
    private int count = 0;

    public void increment() {
        count++;
    }

    public int getCount() {
        return count;
    }
}




/*
//synchornized block
try {
            t1.join();
            t2.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
 */






