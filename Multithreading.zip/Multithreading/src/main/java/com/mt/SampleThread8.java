package com.mt;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class SampleThread8 {

    static long time = System.currentTimeMillis();
    static long count = 0;

    public static void main(String[] args) throws IOException {
        SampleThread8 sampleThread8 = new SampleThread8();
        sampleThread8.receive();

    }

    public void receive() {
        int port = 8080; // Port to listen on
        ExecutorService executor = Executors.newFixedThreadPool(100);

        try (ServerSocket serverSocket = new ServerSocket(port)) {
            System.out.println("Server is listening on port " + port);

            while (true) {
                // Wait for a client to connect
                Socket socket = serverSocket.accept();
                if(count==0) {
                    time = System.currentTimeMillis();
                }
                executor.submit(() ->
                        {
                            try (InputStream input = socket.getInputStream();
                                 BufferedReader reader = new BufferedReader(new InputStreamReader(input)); ) {
                                String text;
                                while ((text = reader.readLine()) != null) {
                                    System.out.println("Request handled by: " + Thread.currentThread() + " time: " + (System.currentTimeMillis() - time) + " Count: " + ++count + " Mesaage: " + text);
                                    synchronized (this) {
                                        this.wait(1000); // Call wait() on the current thread instance
                                    }
                                }
                            } catch (IOException ex) {
                                ex.printStackTrace();
                            } catch (InterruptedException e) {
                                throw new RuntimeException(e);
                            } finally {
                                try {
                                    socket.close();
                                } catch (IOException ex) {
                                    ex.printStackTrace();
                                }
                            }
                        }

                );
            }
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }
}
