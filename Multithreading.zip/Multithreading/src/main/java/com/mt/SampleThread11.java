package com.mt;

import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class SampleThread11 {

    private final Lock lock = new ReentrantLock();

    public void performTask() {
        System.out.println(Thread.currentThread().getName() + " is trying to acquire the lock...");

        try {
            // Try to acquire the lock with a timeout of 2 seconds
            if (lock.tryLock(2, TimeUnit.SECONDS)) {
                try {
                    System.out.println(Thread.currentThread().getName() + " has acquired the lock.");
                    // Simulate some work
                    Thread.sleep(1000);
                    System.out.println(Thread.currentThread().getName() + " has completed.");
                } finally {
                    // Release the lock
                    lock.unlock();
                    System.out.println(Thread.currentThread().getName() + " has released the lock.");
                }
            } else {
                System.out.println(Thread.currentThread().getName() + " could not acquire the lock within the timeout.");
            }
        } catch (InterruptedException e) {
            System.out.println(Thread.currentThread().getName() + " was interrupted.");
        }
    }

    public static void main(String[] args) {
        SampleThread11 example = new SampleThread11();

        // Create multiple threads to compete for the lock
        /*
        This line of code creates a Runnable object that references the performTask method
         of the example object. It's using a Java 8 feature called a "method reference"
         to create a Runnable instance without having to define
         a separate anonymous class or lambda expression.
            In other words, it's equivalent to writing:

            Runnable task = new Runnable() {
                @Override
                public void run() {
                    example.performTask();
                }
            };
         */
        Runnable task = example::performTask;
        Thread thread1 = new Thread(task, "Thread-1");
        Thread thread2 = new Thread(task, "Thread-2");

        thread1.start();
        thread2.start();

        try {
            thread1.join();
            thread2.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        System.out.println("Main thread finished.");
    }
}
