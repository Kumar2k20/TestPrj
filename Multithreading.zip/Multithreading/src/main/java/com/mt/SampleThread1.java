package com.mt;

/* SampleThread1.java
*  This class demonstrates the use of Thread class to create a thread.
* */
public class SampleThread1 {
    public static void main(String[] args) {
        System.out.println(Thread.currentThread().getName() + Thread.currentThread().getId() + " Main Thread");
        MyThread myThread = new MyThread();
        //myThread.setDaemon(true);
        myThread.start();
        //myThread.run();
        /*try {
            myThread.join();
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }*/
        System.out.println(" Main Thread exiting...");
    }

}

class MyThread extends Thread {
    public void run() {
        super.run();
        for(int i = 0; i < 10; i++) {
            System.out.println(Thread.currentThread().getName() + Thread.currentThread().getId() + " Value " + i);
        }
    }
}
