package com.example.resilience_demo.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.cloud.client.circuitbreaker.CircuitBreakerFactory;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
public class ResilienceService {
    private static final Logger logger = LoggerFactory.getLogger(ResilienceService.class);

    @Autowired
    private CircuitBreakerFactory circuitBreakerFactory;

    @Autowired
    private RestTemplate restTemplate;

    String url = "http://localhost:8090/hello";

    public static int count = 1;
    public static int fbcount = 1;
    public static int scount = 1;

    public String getHello() {
        logger.info("Inside getHello method {}", count++);
        return circuitBreakerFactory.create("greeting").run(
                () -> {
                        logger.info("Making a call to the service {}", scount++);
                        return restTemplate.getForObject(url, String.class);
                    },
                    throwable -> {
                        logger.info("Making a call to the fall back method");
                        return fallbackMethod();
                    }
                );
    }

    public String fallbackMethod() {
        return "Fallback response: Service is down " + fbcount++;
    }

}
