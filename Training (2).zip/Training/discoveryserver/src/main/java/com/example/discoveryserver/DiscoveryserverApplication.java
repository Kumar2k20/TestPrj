package com.example.discoveryserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.server.EnableEurekaServer;


/**
 * The @EnableEurekaServer annotation is used in Spring Boot applications to enable
 * the Eureka Server functionality.
 * Eureka Server is a service registry that allows microservices to register themselves
 * at runtime and to discover other registered services.
 * This is a key component in the Netflix OSS stack for building microservices.
 * When you annotate a Spring Boot application with @EnableEurekaServer,
 * it sets up the application as a Eureka Server,
 * which can then be used by other microservices to register and discover services.
 * Here's a brief explanation of what happens when you use @EnableEurekaServer:
 *
 * 1) Service Registration: Microservices can register themselves with the Eureka Server,
 * making their metadata available to other services.
 * 2) Service Discovery: Microservices can query the Eureka Server to find other registered services,
 * enabling them to communicate with each other.
 * 3) Health Checks: Eureka Server periodically checks the health of registered services
 * 	to ensure they are available and functioning correctly.
 * In summary, @EnableEurekaServer is essential for setting up a service registry in a microservices architecture,
 * facilitating service registration, discovery, and health monitoring.
 */

@SpringBootApplication
@EnableEurekaServer
public class DiscoveryserverApplication {

	public static void main(String[] args) {
		SpringApplication.run(DiscoveryserverApplication.class, args);
	}

}
